# Scouting Nederland Wordpress Template

## Nederlands
Omdat vele mensen vragen om een WordPress variant van de Scouting Nederland Joomla template, heb ik hier een kleine opzet voor gemaakt.
De template is nog wel sterk Work in Progress (het is nog niet af). Alle hulp is altijd welkom, zeker omdat ik zelf weinig ervaring heb met Thema ontwikkeling voor Wordpress.

### Veranderingen
#### 0.1
* Toevoeging van het thema (Basis)
* Juiste styling toegepast voor "normale" Wordpress Pagina's
* Instelbare kop-afbeelding

## English
Because a lot of people ask for a WordPress variant for the Cousting Nederland Joomla template, i started developing a Wordpress alternative for it.
This template is very much a work in progress. All help is welcome, especially since i have limited experience regarding wordpress theme development.

### Changelog
#### 0.1
* Added the theme (Basis)
* Added the right styling when using pages
* Adjustable header image